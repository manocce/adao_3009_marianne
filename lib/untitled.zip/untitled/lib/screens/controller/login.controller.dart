import 'package:get/get.dart';

class LoginController extends GetxController{
  final Rx<String> _email = Rx("");
  final Rx<String> _password = Rx("");
  final Rx<String> message = Rx(null);
  final Rx<bool> logged = Rx(false);

  String get email => _email.value;

  String get password => _password.value;

  save(String email, String password){
    bool isValid = true;

    if(email.isEmpty){
      message.value = "Informe o e-mail";
      isValid = false;
    }


    if(password.isEmpty){
      message.value = "Informe o password";
      isValid = false;
    }

    if(isValid){
      //salvar no preference
    }

  }

}