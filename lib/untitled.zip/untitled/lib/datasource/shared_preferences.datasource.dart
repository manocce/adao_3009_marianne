import 'package:shared_preferences/shared_preferences.dart';

class SharedPreferenceDataSource {
  late SharedPreferences _preference;

  initPreference() async{
    _preference = SharedPreferences();
  }
}